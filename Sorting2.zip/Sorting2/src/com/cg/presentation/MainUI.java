package com.cg.presentation;

import java.util.Collections;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import com.cg.bean.Mobile;

import com.cg.service.IMobileService;
import com.cg.service.MobileServiceImpl;
import com.cg.utility.SortByName;
import com.cg.utility.SortByMid;
import com.cg.utility.SortByPrice;



public class MainUI {

	public static void main(String[] args) {
		IMobileService service=new MobileServiceImpl();
		Scanner scanner = null;
		int choice = 0;
		boolean optionFlag = false;
		boolean choiceFlag = false;
		boolean deleteFlag = false;
		try {
			do {
				scanner = new Scanner(System.in);
				List<Mobile> mobilelist = service.getAllMobiles();
				for (Mobile mobile : mobilelist) {
					System.out.println(mobile);
				}
				System.out.println("Enter your choice");
				System.out.println("1.SortByName\n2.SortByPrice\n3.SortByPid\n4.AddMobile\n5.Delete\n6.Display\n7.Exit");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					List<Mobile> mobilelistbyname = service.getAllMobiles();
					Collections.sort(mobilelistbyname, new SortByName());
					display(mobilelistbyname);
					break;
				case 2:
					List<Mobile> mobilelistbyprice = service.getAllMobiles();
					Collections.sort(mobilelistbyprice, new SortByPrice());
					display(mobilelistbyprice);
					break;
				case 3:
					List<Mobile> mobilelistbypid = service.getAllMobiles();
					Collections.sort(mobilelistbypid, new SortByMid());
					display(mobilelistbypid);
					break;
				case 4: {
					System.out.println("Enter mobile id: ");
					int mobileId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter mobile name: ");
					String mobileName = scanner.nextLine();
					System.out.println("Enter mobile price: ");
					int price = scanner.nextInt();
					Mobile mobile = new Mobile(mobileId, mobileName, price);
					
					mobileId=service.addMobile(mobile);
					System.out.println("mobile added successfully with product id:"+mobileId);
				}
					break;	
				case 5: {
					do {
						System.out.println("Enter Mobile Id to delete");
						int mobileId=scanner.nextInt();
						boolean status=service.deleteMobile(mobileId);
						if(status=true) {
							System.out.println( mobileId+ "  Deleted Successfully......");
							deleteFlag=true;
						}else {
							System.out.println("Id not available...");
							
						}
							
					}while(!deleteFlag);
				}
					break;
				case 6:{
					List<Mobile> mobileListByName = service.getAllMobiles();
					display(mobileListByName);
				}break;	
				case 7:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;
				default:
					System.err.println("Enter 1, or 4 only");
					break;	
				}
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!");
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Enter only digits");
		}

	}

	static void display(List<Mobile>mobilelist) {
		for(Mobile mobile : mobilelist) {
			System.out.println(mobile);
		}
	}

}
