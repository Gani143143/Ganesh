package com.cg.bean;

public class Mobile implements Comparable<Mobile>{
	private int mid;
	private String name;
	private double price;
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int mid, String name, double price) {
		super();
		this.mid = mid;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Mobile [mid=" + mid + ", name=" + name + ", price=" + price + "]";
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public int compareTo(Mobile arg0) {
		if(this.mid>mid)
			return 1;
		else if(this.mid<mid)
			return -1;
		else
		return 0;
	}

}
