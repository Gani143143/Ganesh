import { Component, OnInit } from '@angular/core';
import { IStudent } from './student.interface';
import { StudentService } from './student.service';

@Component({
  selector: 'app-searchstudent',
  templateUrl: './searchstudent.component.html',
  styleUrls: ['./searchstudent.component.css']
})
export class SearchstudentComponent implements OnInit {

  students:IStudent[];
  constructor(private studentservice: StudentService) { }

  ngOnInit() {
  }

  searchStudent(data){
    console.log(data);
    console.log(data.name);
    this.students=this.studentservice.getData();
    console.log(this.students);
    this.students=this.students.filter(s=>s.name==data.name);
  }
}
