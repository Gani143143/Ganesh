import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import {IStudent} from './student.interface'
import { Router } from '@angular/router';
@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
  students:IStudent[];
  constructor(private studentService: StudentService,private router:Router) { }
  student:IStudent;
  ngOnInit() {
    if(!this.studentService.getData()){
    this.studentService.getStudents().subscribe(data=>{this.students=data;
      this.studentService.setStudent(this.students);
    });
    
    }else{
      this.students=this.studentService.getData();
    }
  }

  delete(id:number){
   this.studentService.deleteStudent(id);
   this.students=this.studentService.getData();
  }

  update(student:IStudent){
    console.log(student);
    this.router.navigate(['/update',student.id]);
  }

}
