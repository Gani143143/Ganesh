import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentlistComponent } from './student/studentlist.component';
import { AddstudentComponent } from './student/addstudent.component';
import { StartPageComponent } from './student/start-page.component';
import { StudentService } from './student/student.service';
import {FormsModule} from '@angular/forms';
import { SortstudentComponent } from './student/sortstudent.component';
import { SortnamestudentComponent } from './student/sortnamestudent.component';
import { SearchstudentComponent } from './student/searchstudent.component';
import { UpdatestudentComponent } from './student/updatestudent.component';
@NgModule({
  declarations: [
    AppComponent,
    StudentlistComponent,
    AddstudentComponent,
    StartPageComponent,
    SortstudentComponent,
    SortnamestudentComponent,
    SearchstudentComponent,
    UpdatestudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
