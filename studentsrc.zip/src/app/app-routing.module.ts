import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentlistComponent } from './student/studentlist.component';
import { AddstudentComponent } from './student/addstudent.component';
import { StartPageComponent } from './student/start-page.component';
import { SortstudentComponent } from './student/sortstudent.component';
import { SortnamestudentComponent } from './student/sortnamestudent.component';
import { SearchstudentComponent } from './student/searchstudent.component';
import { UpdatestudentComponent } from './student/updatestudent.component';


const routes: Routes = [
  {path: "student", component:StudentlistComponent},
  {path: "add", component:AddstudentComponent},
  {path: "sort", component:SortstudentComponent},
  {path: "sortname", component:SortnamestudentComponent},
  {path: "search", component: SearchstudentComponent},
  {path:"update/:id",component:UpdatestudentComponent},
  {path: '', component: StartPageComponent}//Default route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
