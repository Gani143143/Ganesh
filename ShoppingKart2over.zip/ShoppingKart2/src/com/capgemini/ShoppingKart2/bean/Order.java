package com.capgemini.ShoppingKart2.bean;

public class Order {
private int OrderId;
private int mobile;
private int itemId;
private double quantity;
private double amount;
public Order() {
	super();
}
public Order(int orderId, int id, int itemId, double amount) {
	super();
	OrderId = orderId;
	this.mobile = id;
	this.itemId = itemId;
	this.quantity = amount;
}
public int getOrderId() {
	return OrderId;
}
public void setOrderId(int orderId) {
	OrderId = orderId;
}
public int getMobile() {
	return mobile;
}
public void setMobile(int mobile) {
	this.mobile = mobile;
}
public int getItemId() {
	return itemId;
}
public void setItemId(int itemId) {
	this.itemId = itemId;
}
public double getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
@Override
public String toString() {
	return "Order [OrderId=" + OrderId + ", mobile=" + mobile + ", itemId=" + itemId + ", quantity=" + quantity + "]";
}

}
