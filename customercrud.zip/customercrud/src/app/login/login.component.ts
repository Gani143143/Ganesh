import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string='';
  password:string='';
  constructor() { }

  ngOnInit() {
  }
   login(){
     if(this.username=='admin' && this.password=='admin123'){
       alert("login success");
       sessionStorage.setItem("loginstatus","success");
     }
     else{
        alert("Login Fail");
        sessionStorage.removeItem("loginstatus");
     }
   }
}
