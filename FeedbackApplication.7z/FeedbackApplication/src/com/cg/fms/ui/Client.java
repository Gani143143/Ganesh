package com.cg.fms.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.IFeedbackService;

public class Client {

	public static void main(String[] args) {
		IFeedbackService service=new FeedbackService();
		Scanner scanner=null;
		int choice=0;
		String teacherName=" ";
		boolean choiceFlag=false;
		boolean nameFlag=false;
		do {
			System.out.println("1.Add Feedback");
			System.out.println("2.Print Feedback Report");
			System.out.println("3.Exit");
			scanner=new Scanner(System.in);
			try {
				System.out.println("Enter your choice");
				choice=scanner.nextInt();
				choiceFlag=true;
				switch (choice) {
				case 1:
					scanner=new Scanner(System.in);
					System.out.println("Enter Techer Name");
					teacherName=scanner.nextLine();
					nameFlag=true;
					break;

				default:
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("Choice should be only 1,2 and 3 only");
			}
		} while (!choiceFlag);

	}

}
