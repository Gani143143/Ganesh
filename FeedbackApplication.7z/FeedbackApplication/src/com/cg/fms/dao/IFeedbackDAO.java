package com.cg.fms.dao;

public interface IFeedbackDAO {

}
