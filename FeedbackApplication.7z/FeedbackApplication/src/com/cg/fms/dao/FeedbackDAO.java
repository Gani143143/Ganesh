package com.cg.fms.dao;

public class FeedbackDAO implements IFeedbackDAO {

}
