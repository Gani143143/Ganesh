package com.cg.fms.service;

public interface IFeedbackService {

}
