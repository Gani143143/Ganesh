package com.cg.fms.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.fms.bean.Feedback;

public class FeedbackDB {
	static Map<Integer, Feedback> map=new HashMap<>();
	static {
		map.put(1, new Feedback("Gani",5,"Maths"));
		map.put(2, new Feedback("Anji",5,"Maths"));
		map.put(3, new Feedback("Francis",4,"English"));
		map.put(4, new Feedback("Kinnu",4,"English"));
		
	}
	public static Map<Integer, Feedback> getMap() {
		return map;
	}
	public static void setMap(Map<Integer, Feedback> map) {
		FeedbackDB.map = map;
	}

}
