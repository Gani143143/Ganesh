package com.cg.pd.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

import javax.crypto.ShortBufferException;

import com.cg.pd.bean.Product;
import com.cg.pd.bean.Supplier;
import com.cg.pd.exception.SuperShopperException;
import com.cg.pd.service.IShopperService;
import com.cg.pd.service.ShopperServiceImpl;

public class Client {

	public static void main(String[] args) throws SuperShopperException {
		ShopperServiceImpl shopperService = new ShopperServiceImpl();
		Scanner scanner = new Scanner(System.in);
		boolean validName = false, validQuantity = false , validPrice=false;
		String prodName = "";
		int prodQuantity = 0;
		double prodPrice=0.0;
		do {
			try {
				System.out.println("*************Product Details************");
				System.out.println("1.Add Product Details\n2.Add Supplier Details\n3.Display All Records\n4.Exit");
				int userInput = scanner.nextInt();
				switch (userInput) {
				case 1: {

					scanner.nextLine();
					while (!validName) {
						try {
							System.out.println("Name of Product");
							prodName = scanner.nextLine();
							validName = shopperService.isNameValid(prodName);
							if (!validName) {
								throw new SuperShopperException(
										"" + "Enter 1st letter Capital and should have more than 5 letters");
							}

						} catch (SuperShopperException e) {
							System.err.println(e.getMessage());
						}
					}
					while (!validQuantity) {
						try {

							System.out.println("Quantity");
							prodQuantity = scanner.nextInt();
							validQuantity = shopperService.isQuantityValid(prodQuantity);

						} catch (SuperShopperException e) {
							scanner.nextLine();
							System.err.println(e.getMessage());

							// System.err.println(e.getMessage());

						} catch (InputMismatchException e) {
							scanner.nextLine();
							System.err.println("Enter numeric Values Only \n");

						}
					}
					while (!validPrice) {
						try {

							System.out.println("Price");
							prodPrice = scanner.nextDouble();
							validPrice = shopperService.isPriceValid(prodQuantity);

						} catch (SuperShopperException e) {
							scanner.nextLine();
							System.err.println(e.getMessage());

							// System.err.println(e.getMessage());

						} catch (InputMismatchException e) {
							scanner.nextLine();
							System.err.println("Enter numeric Values Only \n");

						}
					}
					
					Product product = new Product(prodName, prodPrice, prodQuantity);
					int id = shopperService.addProduct(product);
					System.out.println(id);
				}
					break;
				case 2: {
					String name = "";
					while (!validName) {
						try {
							System.out.println("Supplier Name");
							name = scanner.nextLine();
							validName = shopperService.isNameValid(prodName);
							if (!validName) {
								throw new SuperShopperException(
										"" + "Enter 1st letter Capital and should have more than 5 letters");
							}

						} catch (SuperShopperException e) {
							System.err.println(e.getMessage());
						}
					}
					scanner.nextLine();
					System.out.println("Supplier Address");
					String address = scanner.nextLine();
					scanner.nextLine();
					System.out.println("Mobile No.");
					String mobile = scanner.nextLine();
					Supplier supplier = new Supplier(name, mobile, address);
					shopperService.addSupplier(supplier);
				}
					break;
				case 3: {
					System.out.println("---------------Product Details--------------");
					HashMap<Integer, Product> product = new HashMap<Integer, Product>();
					product = shopperService.getAllProducts();
					System.out.println(product);
					System.out.println("---------------Supplier Details--------------");
					System.out.println(shopperService.getAllSuppliers());
				}
					break;
				case 4: {
					scanner.close();
					System.out.println("Thanks Visit Again");
					System.exit(0);
				}

				default: {
					System.err.println("Please enter numeric value between 1 to 4");
				}
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("Please enter a numeric value");
			}

		} while (true);
	}

}
